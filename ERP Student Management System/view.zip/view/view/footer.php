	<footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0.2
        </div>
        <strong>Copyright &copy; 2023-2024<a href="">S.A.S Education</a>.</strong> All rights reserved.
     </footer>
      
  </body>
</html>